                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2961492
Self watering baby groot planter (customizable) by UniversalMaker is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

<big>Don't miss something, subscribe here on thingiverse or on instagramm</big> 
https://www.instagram.com/universalmaker/

This is another cool looking groot planter version, which is a self-watering planter, so that you don’t have to care on watering your plant (you should print it with a size which enables bigger plants to grow in the pot!)

<big> Get some <b>cheap filament</b> and start printing!</big>
https://www.gearbest.com/3d-printer-supplies/pp_651311.html?wid=1433363&lkid=14780363

The pot is online customizable, the groot is too big for that, you have to make it offline, by downloading the openscad software.

do you <b>like that</b>, then you will like my <b>lighted blowball lamp</b>:
https://www.thingiverse.com/thing:2940151


Printed with the Flsun Cube:
https://www.gearbest.com/3d-printers-3d-printer-kits/pp_708167.html?wid=1433363&lkid=14677136

video:
https://www.youtube.com/watch?v=QB-IYQfR2G4

# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.2
Infill: 20%